﻿using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static InchcapeWebApi.Enums.InchcapeEnums;

namespace InchcapeWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleFinancialRatesController : Controller
    {
        private readonly ApplicationDbContext _dbContext;

        public VehicleFinancialRatesController(ApplicationDbContext dbContext)
        {
            this._dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetVehicleFinancialRates()
        {
            var result = await _dbContext.VehicleDetails.ToListAsync();

            if(result.Count == 0)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddVehicleFinancialRates(VehicleDetail addvehicleRequest)
        {
            var newvehicleDetail = new VehicleDetail()
            {
                id = Guid.NewGuid(),
                Model = addvehicleRequest.Model,
                VehicleType = addvehicleRequest.VehicleType,
                FinanceType = addvehicleRequest.FinanceType,
                ZeroToThreeMonths = addvehicleRequest.ZeroToThreeMonths,
                ThreeToSixMonths = addvehicleRequest.ThreeToSixMonths,
                SixToTwelve = addvehicleRequest.SixToTwelve,
                TwelvePlus = addvehicleRequest.TwelvePlus
            };
            await _dbContext.VehicleDetails.AddAsync(newvehicleDetail);
            await _dbContext.SaveChangesAsync();
                        
            return Ok(newvehicleDetail);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> SaveVehicleFinancialRates([FromRoute] Guid id, VehicleDetail updateVehicleRequest)
        {
            var vehicleDetail = await _dbContext.VehicleDetails.FindAsync(id);
            if(vehicleDetail != null)
            {
                vehicleDetail.Model = updateVehicleRequest.Model;
                vehicleDetail.VehicleType = updateVehicleRequest.VehicleType;
                vehicleDetail.FinanceType = updateVehicleRequest.FinanceType;
                vehicleDetail.ZeroToThreeMonths = updateVehicleRequest.ZeroToThreeMonths;
                vehicleDetail.ThreeToSixMonths = updateVehicleRequest.ThreeToSixMonths;
                vehicleDetail.SixToTwelve = updateVehicleRequest.SixToTwelve;
                vehicleDetail.TwelvePlus = updateVehicleRequest.TwelvePlus;

                await _dbContext.SaveChangesAsync();

                return Ok(vehicleDetail);
            }
            return NotFound();
        }
    }
}
