﻿namespace InchcapeWebApi.Enums
{
    public class InchcapeEnums
    {
        public enum VehicleType
        {
            Car,
            Van,
            Bike,
            Bus,
            NineSeater
        }
        public enum FinanceTypes
        {
            FlexibleFinance,
            PersonalLoan,
        }
    }
}
