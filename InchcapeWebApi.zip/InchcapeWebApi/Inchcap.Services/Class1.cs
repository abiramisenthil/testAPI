﻿namespace Inchcap.Services
{
    public class Class1
    {

    }
}