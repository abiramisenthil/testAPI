﻿using InchcapeWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace InchcapeWebApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<VehicleDetail> VehicleDetails { get; set; }

       /* public DbContext Instance => this;

        public Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }*/
    }
}
