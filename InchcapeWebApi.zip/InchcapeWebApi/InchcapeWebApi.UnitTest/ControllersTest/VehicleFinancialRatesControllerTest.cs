using FluentAssertions;
using InchcapeWebApi.Controllers;
using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Reflection.Metadata;

namespace InchcapeWebApi.UnitTest.ControllersTest
{
    public class VehicleFinancialRatesControllerTest
    {
        private Mock<IApplicationDbContext> moqDbContext = new Mock<IApplicationDbContext>();
        [Fact]
        public void GetVehicleFinancialRates_Returns200Status()
        {
            // Arrange
            var mockDataResult = new List<VehicleDetail>()
            {
                new VehicleDetail()
                {
                    id = Guid.NewGuid(),
                    Model = "BMW",
                    VehicleType = "Car",
                    FinanceType = "Pension",
                    ZeroToThreeMonths = 5,
                    ThreeToSixMonths = 6,
                    SixToTwelve = 7,
                    TwelvePlus = 8
                }
            }.AsQueryable();

            var mockSet = new Mock<DbSet<VehicleDetail>>();
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.Provider).Returns(mockDataResult.Provider);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.Expression).Returns(mockDataResult.Expression);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.ElementType).Returns(mockDataResult.ElementType);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.GetEnumerator()).Returns(() => mockDataResult.GetEnumerator());


            var mockContext = new Mock<IApplicationDbContext>();
            mockContext.Setup(m => m.VehicleDetails).Returns(mockSet.Object);
            var sut = new VehicleFinancialRatesController(moqDbContext.Object);
          
            // Act
            var result = sut.GetVehicleFinancialRates();

            // Assert
            result.GetType().Should().Be(typeof(OkObjectResult));
            //(result as OkObjectResult).StatusCode.Should().Be(200);

        }
        [Fact]
        public void Test1()
        {
            // Arrange
            // Act
            // Assert

        }
    }
}